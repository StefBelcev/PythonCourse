if __name__ == "__main__":
    vkupno = 0  #Vkupno e globalna promenliva
    def zbir(x, y):
        vkupno = x + y #Vkupno e lokalna promenliva
        print(f'Vo funkcijata, vkupno =', vkupno)
    zbir(10,20)
    print(f'Nadvor od funkcijata, vkupno =',vkupno)

    pari = 2000 #Globalna promenliva
    def dodadi_pari(x, y):
        global pari
        #Iniciranje na globalna promenliva so naredba global
        # za pari da se zeme od globalniot, a ne lokalniot prostor na iminja na samata funkcija
        pari = pari + 1
    print(pari)
    dodadi_pari(1, 2)
    print(pari)
