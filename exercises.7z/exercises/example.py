if __name__ == "__main__":
    print('Hello')
    z = 5 // 2
    k = 5 / 2
    #povejke kratno dodeluvanje na vrednost
    x,y = 2,3
    a = 10
    c = a
    b = 21
    print(a is b)
    print(z,k,a**b)
    print(x,y)