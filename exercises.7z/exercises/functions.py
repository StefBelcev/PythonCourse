if __name__ == "__main__":
    def call_func(x,func):
        print(func(x))
    def double(n): return n*2
    def triple(n): return n*3
    call_func(3, double)
    call_func(4, triple)
    def hello(word):
        print(f'Hello ' + word)
    hello('World')
    hello('Universe')
    say_hi = hello
    say_hi('Mars')
    say_hi('Jupiter')
