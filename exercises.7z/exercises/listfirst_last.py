if __name__ == "__main__":
    a = [1,2,3,4,5]
    print(a)
    b = [a[0], a[-1]]
    b_second = [a[0]] + [a[-1]]
    print(b)
    print(b_second)